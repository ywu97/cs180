-- createindex.sql

CREATE INDEX LookUpOrders ON Orders(bookID, memberID);
